import boto3
import openai
import pandas as pd
from io import BytesIO
from botocore.exceptions import ClientError

OPENAI_API_KEY = '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'

# def get_secret():
#     secret_name = "OpenAI_API_Key"
#     region_name = "us-east-1"

#     # Create a Secrets Manager client
#     session = boto3.session.Session()
#     client = session.client(
#         service_name='secretsmanager',
#         region_name=region_name
#     )

#     try:
#         get_secret_value_response = client.get_secret_value(
#             SecretId=secret_name
#         )
#     except ClientError as e:
#         print(f"An error occurred: {e}")
#         raise e

#     # Decrypts secret using the associated KMS key.
#     return get_secret_value_response['SecretString']

subcategory_map = [
    'Charity',
    'Catering/Vending/Food', 'Janitorial Services', 'Other Facility Services', 'Pest Control', 'Security Services', 'Waste Disposa', 'Copy Services', 'Document Management/Shredding',
    'Electronic Payment Processing', 'Bank Fees', 'ePayables/Credit Cards/AP Cards', 'Taxes/Fees', 'Merchant Fees',
    'Background Checks/Drug Testing', 'Benefits Admin/Payroll Processing', 'Recruiting/Exec Search', 'Employee Benefits/Training', 'Temporary Labor/Staffing',
    'Employee Insurance', 'Corporate Insurance', 'Professional Liability',
    'IT Infrastructure', 'Hardware', 'Software/Maintainance', 'eDiscovery', 'IT Consulting',
    'Electronic Databases', 'Publications',
    'Commercial Printing/Signage', 'Event Marketing', 'Marketing/Advertising Agencies', 'Digital Marketing', 'Promotional Products',
    'Medical Equipment', 'Medical Supplies', 'Office Equipment', 'Office Furniture', 'Office Supplies', 'MRO',
    'Legal Services', 'General Consulting', 'Financial Service Consulting', 'Engineering Services', 'Medical Services', 'Real Estate Services', 'Office Services', 'Other Services',
    'Building Construction/Repair', 'Facility/Property Rent',
    'Voice/Data Services/Wireless', 'Conferencing',
    'Courier Services', 'Small Parcel Shipping', 'Warehouses/Storage', 'Freight (Trucking, Air, Ocean)', 'Packaging Materials/Supplies', 'Other Logistics',
    'Meals/Entertainment', 'Hotel/Lodging', 'Airfare/Ground Transportation',
    'Electricity', 'Fuel/Natural Gas', 'Water/Sewer', 'Cable', 'Other Utilities'
]

subcategory_category_map = {
    'Charity': 'Charity',
    'Catering/Vending/Food': 'Facilities Management',
    'Janitorial Services': 'Facilities Management',
    'Other Facility Services': 'Facilities Management',
    'Pest Control': 'Facilities Management',
    'Security Services': 'Facilities Management',
    'Waste Disposa': 'Facilities Management',
    'Copy Services': 'Facilities Management',
    'Document Management/Shredding': 'Facilities Management',
    'Electronic Payment Processing': 'Financial Services',
    'Bank Fees': 'Financial Services',
    'ePayables/Credit Cards/AP Cards': 'Financial Services',
    'Taxes/Fees': 'Financial Services',
    'Merchant Fees': 'Financial Services',
    'Background Checks/Drug Testing': 'HR Services',
    'Benefits Admin/Payroll Processing': 'HR Services',
    'Recruiting/Exec Search': 'HR Services',
    'Employee Benefits/Training': 'HR Services',
    'Temporary Labor/Staffing': 'HR Services',
    'Employee Insurance': 'Insurance',
    'Corporate Insurance': 'Insurance',
    'Professional Liability': 'Insurance',
    'IT Infrastructure': 'IT Products/Services',
    'Hardware': 'IT Products/Services',
    'Software/Maintainance': 'IT Products/Services',
    'eDiscovery': 'IT Products/Services',
    'IT Consulting': 'IT Products/Services',
    'Electronic Databases': 'Library',
    'Publications': 'Library',
    'Commercial Printing/Signage': 'Marketing',
    'Event Marketing': 'Marketing',
    'Marketing/Advertising Agencies': 'Marketing',
    'Digital Marketing': 'Marketing',
    'Promotional Products': 'Marketing',
    'Medical Equipment': 'Operating Supplies/Equipment',
    'Medical Supplies': 'Operating Supplies/Equipment',
    'Office Equipment': 'Operating Supplies/Equipment',
    'Office Furniture': 'Operating Supplies/Equipment',
    'Office Supplies': 'Operating Supplies/Equipment',
    'MRO': 'Operating Supplies/Equipment',
    'Legal Services': 'Professional Services',
    'General Consulting': 'Professional Services',
    'Financial Service Consulting': 'Professional Services',
    'Engineering Services': 'Professional Services',
    'Medical Services': 'Professional Services',
    'Real Estate Services': 'Professional Services',
    'Office Services': 'Professional Services',
    'Other Services': 'Professional Services',
    'Building Construction/Repair': 'Real Estate',
    'Facility/Property Rent': 'Real Estate',
    'Voice/Data Services/Wireless': 'Telecommunications',
    'Conferencing': 'Telecommunications',
    'Courier Services': 'Transportation/Logistics',
    'Small Parcel Shipping': 'Transportation/Logistics',
    'Warehouses/Storage': 'Transportation/Logistics',
    'Freight (Trucking, Air, Ocean)': 'Transportation/Logistics',
    'Packaging Materials/Supplies': 'Transportation/Logistics',
    'Other Logistics': 'Transportation/Logistics',
    'Meals/Entertainment': 'Travel/Entertainment',
    'Hotel/Lodging': 'Travel/Entertainment',
    'Airfare/Ground Transportation': 'Travel/Entertainment',
    'Electricity': 'Utilities',
    'Fuel/Natural Gas': 'Utilities',
    'Water/Sewer': 'Utilities',
    'Cable': 'Utilities',
    'Other Utilities': 'Utilities'
}

def lambda_handler(event, context):
    # AWS S3 
    s3 = boto3.client('s3')
    input_bucket_name = 'sw-rawdata'
    output_bucket_name = 'sw-cleandata'
    input_file_name = 'sample400.xlsx'
    output_file_name = '400.xlsx'
    openai.api_key = OPENAI_API_KEY  

    # Download Excel from S3
    response = s3.get_object(Bucket=input_bucket_name, Key=input_file_name)
    excel_data = BytesIO(response['Body'].read())
    df = pd.read_excel(excel_data, engine='openpyxl')  # Assuming the first column contains the company names

    # ChatGPT - category
    categories = []
    subcategories = []
    
    for company in df.iloc[:, 0]:  # Assuming the first column contains the company names
        prompt = f"The company '{company}' belongs to which subcategory from the following list: {subcategory_map}? Please respond only with the exact subcategory name from the list. No additional text or explanations."
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo", 
            messages=[
                {"role": "system", "content": "You are a helpful assistant that provides information about company categories."}, 
                {"role": "user", "content": prompt}])
        chatgpt_response = response.choices[0].message['content'].strip().replace("'", "")
        # Extract the category word
        subcategories.append(chatgpt_response)

        # Map subcategory to category
        category = subcategory_category_map.get(chatgpt_response, "Unknown")
        categories.append(category)

    # Add result to column
    df['Subcategory'] = subcategories
    df['Category'] = categories

    # Save DataFrame to new Excel file
    new_excel_data = BytesIO()
    df.to_excel(new_excel_data, index=False, engine='openpyxl')
    new_excel_data.seek(0)

    # Upload new Excel file to the output S3 bucket
    s3.put_object(Bucket=output_bucket_name, Key=output_file_name, Body=new_excel_data.read())

    return {
        'statusCode': 200,
        'body': 'Processing complete'
    }
